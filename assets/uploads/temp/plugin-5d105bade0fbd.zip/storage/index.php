<?php
    // Silence is golden