<?php 
    header("Location: ../");
    exit;
